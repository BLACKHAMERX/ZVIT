import { Link } from "react-router-dom";
import { ArrowRight } from "lucide-react";

interface HeroSectionProps {
  heroImage: string;
}

const HeroSection = ({ heroImage }: HeroSectionProps) => {
  return (
    <section className="section-navy relative overflow-hidden">
      <div className="container mx-auto px-4 py-12 md:py-20">
        <div className="grid lg:grid-cols-2 gap-8 items-center">
          <div className="space-y-6 animate-slide-in">
            <h1 className="text-3xl md:text-4xl lg:text-5xl font-bold leading-tight">
              Комфортна оренда авто{" "}
              <span className="text-accent">для будь-яких подорожей</span>
            </h1>
            <p className="text-lg text-primary-foreground/80 max-w-lg">
              Обирайте зручний автомобіль для поїздок містом чи подорожей Україною — 
              швидко, просто та доступно.
            </p>
            <Link
              to="/cars"
              className="btn-cta inline-flex items-center gap-2 group"
            >
              Перейти до автомобілів
              <ArrowRight className="h-5 w-5 transition-transform group-hover:translate-x-1" />
            </Link>
          </div>
          
          <div className="relative animate-fade-in">
            <div className="relative rounded-2xl overflow-hidden shadow-2xl">
              <img
                src={heroImage}
                alt="Преміальний автомобіль для оренди"
                className="w-full h-64 md:h-80 lg:h-96 object-cover"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-navy/30 to-transparent" />
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default HeroSection;
