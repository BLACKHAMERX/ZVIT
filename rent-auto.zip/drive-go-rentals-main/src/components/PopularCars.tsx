import { Link } from "react-router-dom";
import { cars } from "@/data/cars";
import CarCard from "./CarCard";
import { ArrowRight } from "lucide-react";

const PopularCars = () => {
  const popularCars = cars.slice(0, 3);

  return (
    <section className="py-16 bg-card">
      <div className="container mx-auto px-4">
        <div className="flex items-center justify-between mb-8">
          <h2 className="text-2xl md:text-3xl font-bold text-primary">
            Найпопулярніше авто
          </h2>
          <Link
            to="/cars"
            className="text-accent hover:text-amber-hover font-medium flex items-center gap-1 group"
          >
            Всі авто
            <ArrowRight className="h-4 w-4 transition-transform group-hover:translate-x-1" />
          </Link>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
          {popularCars.map((car, index) => (
            <div
              key={car.id}
              className="animate-fade-in"
              style={{ animationDelay: `${index * 100}ms` }}
            >
              <CarCard car={car} />
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default PopularCars;
