import { Clock, Wallet, Shield } from "lucide-react";

const features = [
  {
    icon: Clock,
    title: "Зручно",
    description: "Швидке оформлення, онлайн-бронювання та підтримка 24/7",
  },
  {
    icon: Wallet,
    title: "Економно",
    description: "Вигідні ціни та спеціальні пропозиції для кожного клієнта",
  },
  {
    icon: Shield,
    title: "Надійно",
    description: "Сучасні авто у відмінному стані та повна прозорість умов",
  },
];

const FeaturesSection = () => {
  return (
    <section className="section-cream py-16">
      <div className="container mx-auto px-4">
        <div className="grid md:grid-cols-3 gap-8">
          {features.map((feature, index) => (
            <div
              key={feature.title}
              className="flex flex-col items-center text-center p-6 rounded-xl bg-card shadow-sm hover:shadow-md transition-shadow animate-fade-in"
              style={{ animationDelay: `${index * 100}ms` }}
            >
              <div className="bg-primary p-4 rounded-full mb-4">
                <feature.icon className="h-6 w-6 text-primary-foreground" />
              </div>
              <h3 className="text-lg font-semibold mb-2">{feature.title}</h3>
              <p className="text-muted-foreground text-sm">{feature.description}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default FeaturesSection;
