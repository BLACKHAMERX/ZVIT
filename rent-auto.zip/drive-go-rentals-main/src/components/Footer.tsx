import { Car, Phone, Mail, MapPin, Clock } from "lucide-react";
import { Link } from "react-router-dom";

const Footer = () => {
  return (
    <footer className="section-navy py-12">
      <div className="container mx-auto px-4">
        <div className="grid md:grid-cols-3 gap-8">
          {/* Logo & Description */}
          <div>
            <Link to="/" className="flex items-center gap-2 mb-4">
              <div className="bg-accent p-2 rounded-lg">
                <Car className="h-5 w-5 text-accent-foreground" />
              </div>
              <span className="text-xl font-bold">Rent Auto</span>
            </Link>
            <p className="text-primary-foreground/80 text-sm leading-relaxed">
              Комфортна оренда авто для будь-яких подорожей. Швидко, просто та доступно.
            </p>
          </div>

          {/* Quick Links */}
          <div>
            <h4 className="font-semibold mb-4 text-accent">Навігація</h4>
            <ul className="space-y-2">
              <li>
                <Link to="/" className="text-primary-foreground/80 hover:text-accent transition-colors text-sm">
                  Домашня сторінка
                </Link>
              </li>
              <li>
                <Link to="/cars" className="text-primary-foreground/80 hover:text-accent transition-colors text-sm">
                  Вибрати автомобіль
                </Link>
              </li>
              <li>
                <Link to="/contacts" className="text-primary-foreground/80 hover:text-accent transition-colors text-sm">
                  Контакти
                </Link>
              </li>
            </ul>
          </div>

          {/* Contact Info */}
          <div>
            <h4 className="font-semibold mb-4 text-accent">Контакти</h4>
            <ul className="space-y-3">
              <li className="flex items-center gap-3 text-sm text-primary-foreground/80">
                <Phone className="h-4 w-4 text-accent" />
                +38 (067) 123-45-67
              </li>
              <li className="flex items-center gap-3 text-sm text-primary-foreground/80">
                <Mail className="h-4 w-4 text-accent" />
                rentcar.ua@gmail.com
              </li>
              <li className="flex items-start gap-3 text-sm text-primary-foreground/80">
                <MapPin className="h-4 w-4 text-accent mt-0.5" />
                м. Київ, вул. Хрещатик, 25
              </li>
              <li className="flex items-center gap-3 text-sm text-primary-foreground/80">
                <Clock className="h-4 w-4 text-accent" />
                ПН-НД, 08:00 - 22:00
              </li>
            </ul>
          </div>
        </div>

        <div className="border-t border-primary-foreground/20 mt-8 pt-8 text-center">
          <p className="text-sm text-primary-foreground/60">
            © 2024 Rent Auto. Всі права захищені.
          </p>
        </div>
      </div>
    </footer>
  );
};

export default Footer;
