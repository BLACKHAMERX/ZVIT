import { Link } from "react-router-dom";
import { Car } from "@/data/cars";
import { Users, Fuel, Settings } from "lucide-react";

interface CarCardProps {
  car: Car;
}

const CarCard = ({ car }: CarCardProps) => {
  return (
    <div className="card-car">
      <div className="aspect-[4/3] bg-muted relative overflow-hidden">
        {car.image ? (
          <img
            src={car.image}
            alt={`${car.brand} ${car.model}`}
            className="w-full h-full object-cover"
          />
        ) : (
          <div className="w-full h-full flex items-center justify-center bg-gradient-to-br from-muted to-cream-dark">
            <div className="text-center">
              <span className="text-3xl font-bold text-primary/30">{car.brand}</span>
            </div>
          </div>
        )}
      </div>
      
      <div className="p-4">
        <div className="flex items-start justify-between mb-3">
          <div>
            <h3 className="font-bold text-lg text-primary">{car.brand}</h3>
            <p className="text-muted-foreground text-sm">{car.model}</p>
          </div>
          <div className="text-right">
            <span className="text-xl font-bold text-accent">{car.pricePerDay}</span>
            <span className="text-muted-foreground text-sm"> ₴/день</span>
          </div>
        </div>

        <div className="flex items-center gap-4 text-xs text-muted-foreground mb-4">
          <span className="flex items-center gap-1">
            <Users className="h-3.5 w-3.5" /> {car.seats}
          </span>
          <span className="flex items-center gap-1">
            <Settings className="h-3.5 w-3.5" /> {car.transmission}
          </span>
          <span className="flex items-center gap-1">
            <Fuel className="h-3.5 w-3.5" /> {car.fuel}
          </span>
        </div>

        <Link
          to={`/cars/${car.id}`}
          className="btn-cta w-full text-center block text-sm py-2.5"
        >
          Переглянути
        </Link>
      </div>
    </div>
  );
};

export default CarCard;
