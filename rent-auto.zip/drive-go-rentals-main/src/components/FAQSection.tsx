import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from "@/components/ui/accordion";

const faqItems = [
  {
    question: "Як швидко я можу отримати авто?",
    answer: "Оформлення займає всього кілька хвилин. Після підтвердження бронювання ви можете забрати авто протягом години.",
  },
  {
    question: "Які документи потрібні для оренди?",
    answer: "Паспорт та водійське посвідчення — це достатньо для оформлення оренди.",
  },
  {
    question: "Чи можу я орендувати авто на довгий термін?",
    answer: "Так, діє довгострокова оренда зі знижками. Чим довший термін оренди, тим вигідніша ціна за добу.",
  },
  {
    question: "Чи є страхування автомобіля?",
    answer: "Так, всі наші автомобілі застраховані. Базове страхування включено в ціну оренди.",
  },
];

const FAQSection = () => {
  return (
    <section className="section-cream py-16">
      <div className="container mx-auto px-4">
        <div className="max-w-2xl mx-auto">
          <h2 className="text-2xl md:text-3xl font-bold text-center mb-8 text-primary">
            Питання та відповіді
          </h2>
          <Accordion type="single" collapsible className="space-y-3">
            {faqItems.map((item, index) => (
              <AccordionItem
                key={index}
                value={`item-${index}`}
                className="bg-card rounded-lg px-6 border-none shadow-sm"
              >
                <AccordionTrigger className="text-left font-medium hover:no-underline py-4">
                  <span className="text-accent font-bold mr-2">{index + 1}</span>
                  {item.question}
                </AccordionTrigger>
                <AccordionContent className="text-muted-foreground pb-4">
                  {item.answer}
                </AccordionContent>
              </AccordionItem>
            ))}
          </Accordion>
        </div>
      </div>
    </section>
  );
};

export default FAQSection;
