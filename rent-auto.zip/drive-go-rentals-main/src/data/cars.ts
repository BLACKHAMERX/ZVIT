import carBmwM3 from "@/assets/car-bmw-m3.jpg";
import carPorsche from "@/assets/car-porsche.jpg";
import carBmwM4 from "@/assets/car-bmw-m4.jpg";
import carMercedesC63 from "@/assets/car-mercedes-c63.jpg";
import carToyota from "@/assets/car-toyota.jpg";
import carMercedesA45 from "@/assets/car-mercedes-a45.jpg";

export interface Car {
  id: string;
  brand: string;
  model: string;
  pricePerDay: number;
  image: string;
  year: number;
  transmission: "автомат" | "механіка";
  fuel: "бензин" | "дизель" | "електро" | "гібрид";
  seats: number;
  category: "economy" | "comfort" | "premium" | "suv";
}

export const cars: Car[] = [
  {
    id: "1",
    brand: "BMW",
    model: "M3",
    pricePerDay: 2900,
    image: carBmwM3,
    year: 2023,
    transmission: "автомат",
    fuel: "бензин",
    seats: 5,
    category: "premium",
  },
  {
    id: "2",
    brand: "Porsche",
    model: "Panamera",
    pricePerDay: 4500,
    image: carPorsche,
    year: 2023,
    transmission: "автомат",
    fuel: "гібрид",
    seats: 4,
    category: "premium",
  },
  {
    id: "3",
    brand: "BMW",
    model: "M4",
    pricePerDay: 2200,
    image: carBmwM4,
    year: 2022,
    transmission: "автомат",
    fuel: "бензин",
    seats: 4,
    category: "premium",
  },
  {
    id: "4",
    brand: "Mercedes",
    model: "C63",
    pricePerDay: 1900,
    image: carMercedesC63,
    year: 2023,
    transmission: "автомат",
    fuel: "бензин",
    seats: 5,
    category: "comfort",
  },
  {
    id: "5",
    brand: "Toyota",
    model: "Camry",
    pricePerDay: 1100,
    image: carToyota,
    year: 2022,
    transmission: "автомат",
    fuel: "гібрид",
    seats: 5,
    category: "comfort",
  },
  {
    id: "6",
    brand: "Mercedes",
    model: "A45",
    pricePerDay: 1400,
    image: carMercedesA45,
    year: 2023,
    transmission: "автомат",
    fuel: "бензин",
    seats: 5,
    category: "comfort",
  },
];
