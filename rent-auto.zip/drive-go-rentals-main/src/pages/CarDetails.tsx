import { useState } from "react";
import { useParams, Link } from "react-router-dom";
import Header from "@/components/Header";
import Footer from "@/components/Footer";
import { cars } from "@/data/cars";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Calendar } from "@/components/ui/calendar";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { format, differenceInDays } from "date-fns";
import { uk } from "date-fns/locale";
import { CalendarIcon, Users, Fuel, Settings, ChevronLeft, CreditCard, Shield, Check } from "lucide-react";
import { cn } from "@/lib/utils";
import { useToast } from "@/hooks/use-toast";

const CarDetails = () => {
  const { id } = useParams();
  const { toast } = useToast();
  const car = cars.find((c) => c.id === id);
  
  const [startDate, setStartDate] = useState<Date | undefined>(undefined);
  const [endDate, setEndDate] = useState<Date | undefined>(undefined);
  const [name, setName] = useState("");
  const [phone, setPhone] = useState("");
  const [email, setEmail] = useState("");
  const [isBooking, setIsBooking] = useState(false);

  if (!car) {
    return (
      <div className="min-h-screen flex flex-col">
        <Header />
        <main className="flex-1 flex items-center justify-center section-cream">
          <div className="text-center">
            <h1 className="text-2xl font-bold mb-4">Автомобіль не знайдено</h1>
            <Link to="/cars" className="btn-cta inline-block">
              Повернутися до каталогу
            </Link>
          </div>
        </main>
        <Footer />
      </div>
    );
  }

  const totalDays = startDate && endDate ? Math.max(differenceInDays(endDate, startDate), 1) : 0;
  const totalPrice = totalDays * car.pricePerDay;

  const handleBooking = () => {
    if (!startDate || !endDate || !name || !phone || !email) {
      toast({
        title: "Заповніть усі поля",
        description: "Будь ласка, заповніть всі обов'язкові поля форми",
        variant: "destructive",
      });
      return;
    }

    setIsBooking(true);
    
    setTimeout(() => {
      setIsBooking(false);
      toast({
        title: "Бронювання успішне!",
        description: `${car.brand} ${car.model} заброньовано з ${format(startDate, "dd.MM.yyyy")} по ${format(endDate, "dd.MM.yyyy")}`,
      });
    }, 2000);
  };

  return (
    <div className="min-h-screen flex flex-col">
      <Header />
      <main className="flex-1 section-cream py-8">
        <div className="container mx-auto px-4">
          <Link
            to="/cars"
            className="inline-flex items-center gap-2 text-muted-foreground hover:text-primary transition-colors mb-6"
          >
            <ChevronLeft className="h-4 w-4" />
            Назад до каталогу
          </Link>

          <div className="grid lg:grid-cols-2 gap-8">
            {/* Car Image & Info */}
            <div className="space-y-6">
              <div className="aspect-[16/10] bg-card rounded-2xl overflow-hidden shadow-lg">
                {car.image ? (
                  <img
                    src={car.image}
                    alt={`${car.brand} ${car.model}`}
                    className="w-full h-full object-cover"
                  />
                ) : (
                  <div className="w-full h-full flex items-center justify-center bg-gradient-to-br from-muted to-cream-dark">
                    <span className="text-5xl font-bold text-primary/20">{car.brand}</span>
                  </div>
                )}
              </div>

              <div className="bg-card rounded-xl p-6 shadow-sm">
                <h1 className="text-3xl font-bold text-primary mb-2">
                  {car.brand} {car.model}
                </h1>
                <p className="text-muted-foreground mb-4">{car.year} рік</p>

                <div className="grid grid-cols-3 gap-4 mb-6">
                  <div className="flex items-center gap-2 text-sm">
                    <Users className="h-5 w-5 text-accent" />
                    <span>{car.seats} місць</span>
                  </div>
                  <div className="flex items-center gap-2 text-sm">
                    <Settings className="h-5 w-5 text-accent" />
                    <span>{car.transmission}</span>
                  </div>
                  <div className="flex items-center gap-2 text-sm">
                    <Fuel className="h-5 w-5 text-accent" />
                    <span>{car.fuel}</span>
                  </div>
                </div>

                <div className="flex items-baseline gap-2">
                  <span className="text-3xl font-bold text-accent">{car.pricePerDay} ₴</span>
                  <span className="text-muted-foreground">/ день</span>
                </div>
              </div>
            </div>

            {/* Booking Form */}
            <div className="bg-card rounded-2xl p-6 shadow-lg h-fit">
              <h2 className="text-xl font-bold text-primary mb-6">Забронювати автомобіль</h2>

              <div className="space-y-4">
                <div className="grid sm:grid-cols-2 gap-4">
                  <div>
                    <Label className="mb-2 block">Дата початку</Label>
                    <Popover>
                      <PopoverTrigger asChild>
                        <Button
                          variant="outline"
                          className={cn(
                            "w-full justify-start text-left font-normal",
                            !startDate && "text-muted-foreground"
                          )}
                        >
                          <CalendarIcon className="mr-2 h-4 w-4" />
                          {startDate ? format(startDate, "dd.MM.yyyy", { locale: uk }) : "Оберіть дату"}
                        </Button>
                      </PopoverTrigger>
                      <PopoverContent className="w-auto p-0">
                        <Calendar
                          mode="single"
                          selected={startDate}
                          onSelect={setStartDate}
                          disabled={(date) => date < new Date()}
                        />
                      </PopoverContent>
                    </Popover>
                  </div>

                  <div>
                    <Label className="mb-2 block">Дата завершення</Label>
                    <Popover>
                      <PopoverTrigger asChild>
                        <Button
                          variant="outline"
                          className={cn(
                            "w-full justify-start text-left font-normal",
                            !endDate && "text-muted-foreground"
                          )}
                        >
                          <CalendarIcon className="mr-2 h-4 w-4" />
                          {endDate ? format(endDate, "dd.MM.yyyy", { locale: uk }) : "Оберіть дату"}
                        </Button>
                      </PopoverTrigger>
                      <PopoverContent className="w-auto p-0">
                        <Calendar
                          mode="single"
                          selected={endDate}
                          onSelect={setEndDate}
                          disabled={(date) => date < (startDate || new Date())}
                        />
                      </PopoverContent>
                    </Popover>
                  </div>
                </div>

                <div>
                  <Label htmlFor="name" className="mb-2 block">Ім'я та прізвище</Label>
                  <Input
                    id="name"
                    value={name}
                    onChange={(e) => setName(e.target.value)}
                    placeholder="Введіть ваше ім'я"
                  />
                </div>

                <div>
                  <Label htmlFor="phone" className="mb-2 block">Телефон</Label>
                  <Input
                    id="phone"
                    type="tel"
                    value={phone}
                    onChange={(e) => setPhone(e.target.value)}
                    placeholder="+38 (0__) ___-__-__"
                  />
                </div>

                <div>
                  <Label htmlFor="email" className="mb-2 block">Email</Label>
                  <Input
                    id="email"
                    type="email"
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    placeholder="example@email.com"
                  />
                </div>

                {totalDays > 0 && (
                  <div className="bg-muted rounded-lg p-4 space-y-2">
                    <div className="flex justify-between text-sm">
                      <span>Тривалість оренди:</span>
                      <span className="font-medium">{totalDays} {totalDays === 1 ? "день" : "днів"}</span>
                    </div>
                    <div className="flex justify-between text-sm">
                      <span>Ціна за день:</span>
                      <span className="font-medium">{car.pricePerDay} ₴</span>
                    </div>
                    <div className="border-t border-border pt-2 flex justify-between">
                      <span className="font-semibold">Загальна вартість:</span>
                      <span className="text-xl font-bold text-accent">{totalPrice} ₴</span>
                    </div>
                  </div>
                )}

                <Button
                  className="btn-cta w-full"
                  onClick={handleBooking}
                  disabled={isBooking}
                >
                  {isBooking ? (
                    "Обробка..."
                  ) : (
                    <>
                      <CreditCard className="mr-2 h-5 w-5" />
                      Забронювати та оплатити
                    </>
                  )}
                </Button>

                <div className="flex items-center gap-4 text-xs text-muted-foreground pt-2">
                  <span className="flex items-center gap-1">
                    <Shield className="h-4 w-4 text-accent" />
                    Безпечна оплата
                  </span>
                  <span className="flex items-center gap-1">
                    <Check className="h-4 w-4 text-accent" />
                    Миттєве підтвердження
                  </span>
                </div>
              </div>
            </div>
          </div>
        </div>
      </main>
      <Footer />
    </div>
  );
};

export default CarDetails;
