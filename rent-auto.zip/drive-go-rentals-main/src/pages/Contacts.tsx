import Header from "@/components/Header";
import Footer from "@/components/Footer";
import { Phone, Mail, MapPin, Clock, Users, Car, Star, Shield } from "lucide-react";

const stats = [
  { value: "10 000+", label: "задоволених клієнтів", icon: Users },
  { value: "100+", label: "сучасних машин", icon: Car },
  { value: "98%", label: "позитивних відгуків", icon: Star },
  { value: "5+", label: "років на ринку", icon: Shield },
];

const Contacts = () => {
  return (
    <div className="min-h-screen flex flex-col">
      <Header />
      <main className="flex-1">
        {/* About Section */}
        <section className="section-navy py-16">
          <div className="container mx-auto px-4">
            <h1 className="text-3xl md:text-4xl font-bold mb-6 text-center">Про Нас</h1>
            <p className="max-w-2xl mx-auto text-center text-primary-foreground/80 text-lg leading-relaxed">
              Ми — компанія Rent Auto, яка вже понад 5 років допомагає клієнтам подорожувати з комфортом. 
              Наша мета — зробити оренду автомобіля максимально простою, доступною та надійною.
            </p>
          </div>
        </section>

        {/* Stats Section */}
        <section className="section-cream py-16">
          <div className="container mx-auto px-4">
            <h2 className="text-2xl md:text-3xl font-bold text-primary text-center mb-10">
              Наші досягнення
            </h2>
            <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-6">
              {stats.map((stat, index) => (
                <div
                  key={stat.label}
                  className="bg-card rounded-xl p-6 text-center shadow-sm hover:shadow-md transition-shadow animate-fade-in"
                  style={{ animationDelay: `${index * 100}ms` }}
                >
                  <div className="bg-primary p-3 rounded-full w-fit mx-auto mb-4">
                    <stat.icon className="h-6 w-6 text-primary-foreground" />
                  </div>
                  <div className="text-3xl font-bold text-accent mb-1">{stat.value}</div>
                  <div className="text-muted-foreground text-sm">{stat.label}</div>
                </div>
              ))}
            </div>
          </div>
        </section>

        {/* Contact Section */}
        <section className="py-16 bg-card">
          <div className="container mx-auto px-4">
            <h2 className="text-2xl md:text-3xl font-bold text-primary text-center mb-4">
              Контакти
            </h2>
            <p className="text-center text-muted-foreground mb-10 max-w-lg mx-auto">
              Ми завжди на зв'язку та готові допомогти вам із орендою авто. 
              Оберіть зручний спосіб зв'язку.
            </p>

            <div className="max-w-2xl mx-auto">
              <div className="bg-muted rounded-2xl p-8 space-y-6">
                <div className="flex items-start gap-4">
                  <div className="bg-primary p-3 rounded-lg">
                    <Phone className="h-5 w-5 text-primary-foreground" />
                  </div>
                  <div>
                    <h3 className="font-semibold text-primary">Телефон</h3>
                    <a href="tel:+380671234567" className="text-accent hover:underline">
                      +38 (067) 123-45-67
                    </a>
                  </div>
                </div>

                <div className="flex items-start gap-4">
                  <div className="bg-primary p-3 rounded-lg">
                    <Mail className="h-5 w-5 text-primary-foreground" />
                  </div>
                  <div>
                    <h3 className="font-semibold text-primary">E-mail</h3>
                    <a href="mailto:rentcar.ua@gmail.com" className="text-accent hover:underline">
                      rentcar.ua@gmail.com
                    </a>
                  </div>
                </div>

                <div className="flex items-start gap-4">
                  <div className="bg-primary p-3 rounded-lg">
                    <MapPin className="h-5 w-5 text-primary-foreground" />
                  </div>
                  <div>
                    <h3 className="font-semibold text-primary">Адреса офісу</h3>
                    <p className="text-muted-foreground">м. Київ, вул. Хрещатик, 25</p>
                  </div>
                </div>

                <div className="flex items-start gap-4">
                  <div className="bg-primary p-3 rounded-lg">
                    <Clock className="h-5 w-5 text-primary-foreground" />
                  </div>
                  <div>
                    <h3 className="font-semibold text-primary">Графік роботи</h3>
                    <p className="text-muted-foreground">ПН-НД, 08:00 - 22:00</p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </section>
      </main>
      <Footer />
    </div>
  );
};

export default Contacts;
